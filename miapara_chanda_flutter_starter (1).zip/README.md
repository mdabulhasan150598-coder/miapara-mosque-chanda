# মিয়াপাড়া কেন্দ্রীয় জামে মসজিদ — মাসিক চাঁদা হিসাব (Flutter starter)

এটি একটি **প্রাথমিক source-code scaffold**, তৈরি APK নয়। এটি Flutter প্রকল্পের ভিত্তি দেয়; বাস্তব ব্যবহারের আগে Firebase project setup, security rules deployment, sync conflict handling, PDF/Excel export, tests এবং বাস্তব ডিভাইস পরীক্ষা সম্পন্ন করতে হবে।

## প্রস্তাবিত পরিবেশ
- Flutter stable SDK
- Android Studio / Android SDK
- Firebase project
- `flutterfire configure` চালিয়ে `lib/firebase_options.dart` তৈরি করুন

## শুরু
1. ZIP extract করুন।
2. `flutter create .` চালিয়ে Android platform files তৈরি/পূরণ করুন (প্রয়োজনে)।
3. `flutter pub get`
4. Firebase-এর জন্য `flutterfire configure`।
5. `lib/main.dart`-এ Firebase initialization চালু করার আগে `firebase_options.dart` তৈরি করুন।
6. `firestore.rules` পর্যালোচনা করে Firebase Console/CLI দিয়ে deploy করুন।
7. `flutter run`

## এই scaffold-এ আছে
- বাংলা ড্যাশবোর্ড ও চাঁদাদার তালিকার প্রাথমিক UI
- SQLite schema এবং member/payment repository-এর নমুনা
- প্রতিটি payment-এর UUID/idempotency key
- Firebase sync-এর জন্য আলাদা service boundary
- Firestore security rules-এর starter
- ২০২৫ থেকে বছর/মাসভিত্তিক হিসাবের ডেটা মডেল

## এখনও সম্পূর্ণ করতে হবে
- পূর্ণ offline outbox queue এবং retry/backoff
- Firebase Authentication-এ admin-created accounts
- প্রতিষ্ঠানভিত্তিক membership/role enforcement
- server-side transaction/Cloud Function দিয়ে online duplicate prevention
- PDF/Excel export, share/print, receipt numbering
- data migration/import wizard ও backup restore
- automated tests, security review, real device tests

## গুরুত্বপূর্ণ হিসাবনীতি
- `payments` হলো জমার প্রকৃত লেনদেনের রেকর্ড; জমা মুছে না দিয়ে reversal/void audit trail রাখুন।
- একটি লেনদেন একাধিক মাসে বরাদ্দ হতে পারে; production schema-তে `payment_allocations` ব্যবহার করুন।
- পুরোনো চাঁদার হার বদলালে আগের মাসের হিসাব বদলাবেন না; effective-date ভিত্তিক `contribution_rates` রাখুন।
- শুধু local SQLite-কে backup ভাববেন না। encrypted/exported backup এবং restore test রাখুন।
