# Data model and accounting rules

## Money
Store money as integer paisa (`amount_paisa`) to avoid floating point rounding errors.
Example: ৳২০০ = 20000 paisa.

## Monthly accounting
- Every member has an effective-dated contribution rate.
- Each receipt is a payment transaction.
- `payment_allocations` maps each payment to one or more year/month periods.
- Monthly due = applicable monthly rate - allocated payments for that member/month.
- Carry-forward arrears should be computed from monthly ledger entries, not manually copied.
- A partial payment is valid and leaves a balance due.
- Reversals must create an auditable reversing entry; never silently delete a synced payment.

## Historical import
Import 2025 onward with a reviewable CSV/Excel template:
member_id, name, phone, year, month, monthly_rate_paisa, paid_amount_paisa, paid_date, notes.
Rows with unreadable or ambiguous source-book entries must be marked for manual confirmation.
Never guess handwritten amounts/dates.
