# Implementation phases

1. Confirm business rules: institution ID, calendar, rate changes, partial payment, arrears carry-forward, receipt numbering.
2. Build member CRUD and SQLite migrations.
3. Implement ledger calculation and automated tests.
4. Add payment allocation, receipts, audit trail, reversal workflow.
5. Add admin-created Firebase Auth users and server-enforced roles.
6. Implement sync outbox, idempotent server writes, conflict review, offline tests.
7. Add Bengali PDF, printing, XLSX export, backup/restore.
8. Import historical 2025+ data and reconcile totals against the paper register.
9. Test on multiple Android devices, sign release APK, protect signing key.
