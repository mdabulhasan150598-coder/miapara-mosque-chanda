import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'data/app_database.dart';
import 'data/member_repository.dart';
import 'models/member.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Firebase init after `flutterfire configure`:
  // await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  await AppDatabase.instance.database;
  runApp(const ChandaApp());
}

class ChandaApp extends StatelessWidget {
  const ChandaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'মাসিক চাঁদা হিসাব',
      debugShowCheckedModeBanner: false,
      locale: const Locale('bn', 'BD'),
      supportedLocales: const [Locale('bn', 'BD'), Locale('en', 'US')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF087443)),
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFFF5F8F5),
      ),
      home: const DashboardPage(),
    );
  }
}

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  final _repo = MemberRepository();
  List<Member> _members = [];
  bool _loading = true;
  String _query = '';

  @override
  void initState() {
    super.initState();
    _loadMembers();
  }

  Future<void> _loadMembers() async {
    final rows = await _repo.search(_query);
    if (!mounted) return;
    setState(() {
      _members = rows;
      _loading = false;
    });
  }

  Future<void> _addDemoMember() async {
    final now = DateTime.now();
    await _repo.save(Member(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      name: 'নমুনা চাঁদাদার',
      phone: '',
      address: '',
      monthlyAmountPaisa: 20000, // ২০০ টাকা; amount stored in paisa
      joinedAt: now,
      active: true,
      updatedAt: now,
    ));
    await _loadMembers();
  }

  String money(int paisa) => '৳ ${(paisa / 100).toStringAsFixed(2)}';

  @override
  Widget build(BuildContext context) {
    final totalMembers = _members.length;
    return Scaffold(
      appBar: AppBar(
        title: const Text('মাসিক চাঁদা হিসাব'),
        backgroundColor: const Color(0xFF087443),
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            tooltip: 'নমুনা চাঁদাদার যোগ করুন',
            onPressed: _addDemoMember,
            icon: const Icon(Icons.person_add_alt_1),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text(
            'মিয়াপাড়া কেন্দ্রীয় জামে মসজিদ',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  const CircleAvatar(
                    backgroundColor: Color(0xFFDDF4E6),
                    child: Icon(Icons.groups, color: Color(0xFF087443)),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('এই ডিভাইসে সংরক্ষিত চাঁদাদার'),
                        Text(
                          '$totalMembers জন',
                          style: const TextStyle(
                            fontSize: 24, fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            decoration: const InputDecoration(
              prefixIcon: Icon(Icons.search),
              hintText: 'নাম বা মোবাইল নম্বর দিয়ে খুঁজুন',
              border: OutlineInputBorder(),
              filled: true,
            ),
            onChanged: (value) {
              _query = value;
              _loadMembers();
            },
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              const Expanded(
                child: Text('চাঁদাদারের তালিকা',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              ),
              TextButton.icon(
                onPressed: _loadMembers,
                icon: const Icon(Icons.refresh),
                label: const Text('রিফ্রেশ'),
              ),
            ],
          ),
          if (_loading)
            const Center(child: CircularProgressIndicator())
          else if (_members.isEmpty)
            const Card(
              child: Padding(
                padding: EdgeInsets.all(20),
                child: Text(
                  'এখনো কোনো চাঁদাদার নেই। উপরের ব্যক্তি যোগ করার বোতামটি শুধু নমুনা ডেটা যোগ করে। '
                  'বাস্তব অ্যাপে এখানে “নতুন চাঁদাদার” ফর্ম থাকবে।',
                ),
              ),
            )
          else
            ..._members.map((m) => Card(
                  child: ListTile(
                    leading: CircleAvatar(child: Text(m.name.isEmpty ? '?' : m.name[0])),
                    title: Text(m.name),
                    subtitle: Text('${m.phone.isEmpty ? 'মোবাইল দেওয়া হয়নি' : m.phone}\n'
                        'মাসিক চাঁদা: ${money(m.monthlyAmountPaisa)}'),
                    isThreeLine: true,
                    trailing: Icon(
                      m.active ? Icons.check_circle : Icons.pause_circle,
                      color: m.active ? Colors.green : Colors.grey,
                    ),
                  ),
                )),
          const SizedBox(height: 16),
          const Text(
            'পরবর্তী ধাপ: জমা গ্রহণ, মাসভিত্তিক রেজিস্টার, বকেয়া, রসিদ, PDF/Excel এবং Firebase সিঙ্ক যুক্ত করা।',
            style: TextStyle(color: Colors.black54),
          ),
        ],
      ),
    );
  }
}
