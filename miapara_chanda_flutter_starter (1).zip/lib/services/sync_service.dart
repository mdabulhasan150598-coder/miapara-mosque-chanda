/// Production sync requirements:
/// 1. Save local entity + outbox row in one SQLite transaction.
/// 2. Upload using stable UUID IDs; never generate a new ID on retry.
/// 3. Server must reject duplicate payment IDs and validate allocations.
/// 4. Do not silently overwrite concurrent edits; use version/updatedAt and conflict review.
/// 5. Mark outbox complete only after server acknowledgement.
/// 6. Retry transient errors with exponential backoff; surface permanent errors to admin.
///
/// Firebase Firestore offline persistence alone is not a replacement for this outbox:
/// the app also needs deterministic local accounting and a tested reconciliation strategy.
class SyncService {
  Future<void> syncPendingChanges() async {
    // TODO: read sync_outbox in creation order.
    // TODO: send to an authenticated callable Cloud Function or transaction handler.
    // TODO: mark synced only after acknowledged server response.
  }
}
