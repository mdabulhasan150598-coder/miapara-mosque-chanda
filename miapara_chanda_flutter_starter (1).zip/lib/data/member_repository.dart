import 'package:sqflite/sqflite.dart';
import '../models/member.dart';
import 'app_database.dart';

class MemberRepository {
  Future<void> save(Member member) async {
    final Database db = await AppDatabase.instance.database;
    await db.insert(
      'members',
      {...member.toMap(), 'sync_state': 'pending'},
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
    // Production: enqueue a JSON payload in sync_outbox in the same DB transaction.
  }

  Future<List<Member>> search(String query) async {
    final db = await AppDatabase.instance.database;
    final q = query.trim();
    final rows = await db.query(
      'members',
      where: q.isEmpty ? null : '(name LIKE ? OR phone LIKE ?)',
      whereArgs: q.isEmpty ? null : ['%$q%', '%$q%'],
      orderBy: 'name COLLATE NOCASE ASC',
      limit: 500,
    );
    return rows.map(Member.fromMap).toList();
  }
}
