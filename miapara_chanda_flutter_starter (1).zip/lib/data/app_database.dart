import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

class AppDatabase {
  AppDatabase._();
  static final AppDatabase instance = AppDatabase._();
  Database? _db;

  Future<Database> get database async {
    if (_db != null) return _db!;
    final path = p.join(await getDatabasesPath(), 'miapara_chanda.db');
    _db = await openDatabase(
      path,
      version: 1,
      onConfigure: (db) async {
        await db.execute('PRAGMA foreign_keys = ON');
      },
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE members (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            phone TEXT NOT NULL DEFAULT '',
            address TEXT NOT NULL DEFAULT '',
            monthly_amount_paisa INTEGER NOT NULL CHECK(monthly_amount_paisa >= 0),
            joined_at TEXT NOT NULL,
            active INTEGER NOT NULL DEFAULT 1,
            updated_at TEXT NOT NULL,
            sync_state TEXT NOT NULL DEFAULT 'pending'
          )
        ''');
        await db.execute('CREATE INDEX idx_members_name ON members(name)');
        await db.execute('CREATE INDEX idx_members_phone ON members(phone)');
        await db.execute('''
          CREATE TABLE payments (
            id TEXT PRIMARY KEY,
            member_id TEXT NOT NULL,
            amount_paisa INTEGER NOT NULL CHECK(amount_paisa > 0),
            paid_at TEXT NOT NULL,
            received_by_user_id TEXT NOT NULL,
            receipt_number TEXT NOT NULL UNIQUE,
            status TEXT NOT NULL DEFAULT 'pending_sync',
            created_at TEXT NOT NULL,
            FOREIGN KEY(member_id) REFERENCES members(id)
          )
        ''');
        await db.execute('CREATE INDEX idx_payments_member_date ON payments(member_id, paid_at)');
        await db.execute('''
          CREATE TABLE payment_allocations (
            id TEXT PRIMARY KEY,
            payment_id TEXT NOT NULL,
            member_id TEXT NOT NULL,
            year INTEGER NOT NULL CHECK(year >= 2025),
            month INTEGER NOT NULL CHECK(month BETWEEN 1 AND 12),
            amount_paisa INTEGER NOT NULL CHECK(amount_paisa > 0),
            FOREIGN KEY(payment_id) REFERENCES payments(id),
            UNIQUE(payment_id, year, month)
          )
        ''');
        await db.execute('''
          CREATE TABLE contribution_rates (
            id TEXT PRIMARY KEY,
            member_id TEXT NOT NULL,
            monthly_amount_paisa INTEGER NOT NULL CHECK(monthly_amount_paisa >= 0),
            effective_from_year INTEGER NOT NULL,
            effective_from_month INTEGER NOT NULL CHECK(effective_from_month BETWEEN 1 AND 12),
            FOREIGN KEY(member_id) REFERENCES members(id),
            UNIQUE(member_id, effective_from_year, effective_from_month)
          )
        ''');
        await db.execute('''
          CREATE TABLE users (
            id TEXT PRIMARY KEY,
            display_name TEXT NOT NULL,
            role TEXT NOT NULL CHECK(role IN ('admin','collector','viewer')),
            active INTEGER NOT NULL DEFAULT 1
          )
        ''');
        await db.execute('''
          CREATE TABLE sync_outbox (
            id TEXT PRIMARY KEY,
            entity_type TEXT NOT NULL,
            entity_id TEXT NOT NULL,
            operation TEXT NOT NULL,
            payload_json TEXT NOT NULL,
            created_at TEXT NOT NULL,
            retry_count INTEGER NOT NULL DEFAULT 0,
            UNIQUE(entity_type, entity_id, operation)
          )
        ''');
        await db.execute('''
          CREATE TABLE audit_log (
            id TEXT PRIMARY KEY,
            actor_user_id TEXT NOT NULL,
            action TEXT NOT NULL,
            entity_type TEXT NOT NULL,
            entity_id TEXT NOT NULL,
            details_json TEXT NOT NULL,
            created_at TEXT NOT NULL
          )
        ''');
      },
    );
    return _db!;
  }
}
