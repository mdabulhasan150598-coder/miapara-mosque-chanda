class Member {
  final String id;
  final String name;
  final String phone;
  final String address;
  /// Store money as integer paisa to avoid floating-point rounding errors.
  final int monthlyAmountPaisa;
  final DateTime joinedAt;
  final bool active;
  final DateTime updatedAt;

  const Member({
    required this.id,
    required this.name,
    required this.phone,
    required this.address,
    required this.monthlyAmountPaisa,
    required this.joinedAt,
    required this.active,
    required this.updatedAt,
  });

  Map<String, Object?> toMap() => {
    'id': id,
    'name': name,
    'phone': phone,
    'address': address,
    'monthly_amount_paisa': monthlyAmountPaisa,
    'joined_at': joinedAt.toIso8601String(),
    'active': active ? 1 : 0,
    'updated_at': updatedAt.toIso8601String(),
  };

  factory Member.fromMap(Map<String, Object?> map) => Member(
    id: map['id'] as String,
    name: map['name'] as String,
    phone: map['phone'] as String? ?? '',
    address: map['address'] as String? ?? '',
    monthlyAmountPaisa: map['monthly_amount_paisa'] as int,
    joinedAt: DateTime.parse(map['joined_at'] as String),
    active: (map['active'] as int) == 1,
    updatedAt: DateTime.parse(map['updated_at'] as String),
  );
}
