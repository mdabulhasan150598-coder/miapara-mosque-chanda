class Payment {
  final String id; // UUID idempotency key generated once on device
  final String memberId;
  final int amountPaisa;
  final DateTime paidAt;
  final String receivedByUserId;
  final String receiptNumber;
  final String status; // pending_sync, synced, reversed
  final DateTime createdAt;

  const Payment({
    required this.id,
    required this.memberId,
    required this.amountPaisa,
    required this.paidAt,
    required this.receivedByUserId,
    required this.receiptNumber,
    required this.status,
    required this.createdAt,
  });

  Map<String, Object?> toMap() => {
    'id': id,
    'member_id': memberId,
    'amount_paisa': amountPaisa,
    'paid_at': paidAt.toIso8601String(),
    'received_by_user_id': receivedByUserId,
    'receipt_number': receiptNumber,
    'status': status,
    'created_at': createdAt.toIso8601String(),
  };
}
